export const colors = {
  bgColor: "#1a1516",
  bgSettingsColor: "#fff",
  primary: "#bd0023",
  buttonPrimary: "#841584",
  headerColor: "#1a1917",
  selectedTab: "#fff",
  delete: "#b8352c",
  buttonMute: "#bd0023",
  buttonUnmute: "#098f45",
};
